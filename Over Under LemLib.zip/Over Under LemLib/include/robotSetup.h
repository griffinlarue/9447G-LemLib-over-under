#pragma once
#include "main.h"

//motors:
#define fwport 18
#define IMUPort 7
#define KickerPort 16
#define IntakePort 12
#define LiftUpPort 'g'
#define LiftDownPort 'f'
#define WingPort 'h'
#define HangPort 'e'
#define LeftDriveFront 8
#define LeftDriveBottom 9
#define LeftDriveTop 10
#define RightDriveFront 3
#define RightDriveBottom 2
#define RightDriveTop 4


//carts:
#define redCart pros::motor_gearset_e_t::E_MOTOR_GEARSET_36
#define greenCart pros::motor_gearset_e_t::E_MOTOR_GEARSET_18
#define blueCart pros::motor_gearset_e_t::E_MOTOR_GEARSET_06

//controller buttons: (from Rhett from 9623D)
#define L1 pros::controller_digital_e_t::E_CONTROLLER_DIGITAL_L1
#define L2 pros::controller_digital_e_t::E_CONTROLLER_DIGITAL_L2
#define R1 pros::controller_digital_e_t::E_CONTROLLER_DIGITAL_R1
#define R2 pros::controller_digital_e_t::E_CONTROLLER_DIGITAL_R2
#define A pros::controller_digital_e_t::E_CONTROLLER_DIGITAL_A
#define B pros::controller_digital_e_t::E_CONTROLLER_DIGITAL_B
#define X pros::controller_digital_e_t::E_CONTROLLER_DIGITAL_X
#define Y pros::controller_digital_e_t::E_CONTROLLER_DIGITAL_Y
#define Up pros::controller_digital_e_t::E_CONTROLLER_DIGITAL_UP
#define Down pros::controller_digital_e_t::E_CONTROLLER_DIGITAL_DOWN
#define Right pros::controller_digital_e_t::E_CONTROLLER_DIGITAL_RIGHT
#define Left pros::controller_digital_e_t::E_CONTROLLER_DIGITAL_LEFT
#define LeftX pros::controller_analog_e_t::E_CONTROLLER_ANALOG_LEFT_X
#define LeftY pros::controller_analog_e_t::E_CONTROLLER_ANALOG_LEFT_Y
#define RightX pros::controller_analog_e_t::E_CONTROLLER_ANALOG_RIGHT_X
#define RightY pros::controller_analog_e_t::E_CONTROLLER_ANALOG_RIGHT_Y

// Drive motor definitions
pros::Motor LDF (LeftDriveFront, true);
pros::Motor LDB (LeftDriveBottom, true);
pros::Motor LDT (LeftDriveTop, false);
pros::Motor RDF (RightDriveFront, false);
pros::Motor RDB (RightDriveBottom, false);
pros::Motor RDT (RightDriveTop, true);

//left and right side definitions
pros::Motor_Group driveleft ( {LDF , LDB , LDT});
pros::Motor_Group driveright ( {RDF , RDB , RDT});

//odometry definitions
pros::Imu imu(IMUPort);


pros::Controller master(pros::E_CONTROLLER_MASTER);

//lemlib drivetrain constructor

lemlib::Drivetrain drivetrain
{ 
    &driveleft,
    &driveright,
    10.125,
    4.125,
    300,
    6

};

lemlib::OdomSensors odomsensors
{
    	nullptr,
		nullptr, /*No Tracking Wheel*/
		nullptr, /*No Tracking Wheel*/
		nullptr, /*No Tracking Wheel*/
		&imu /*Inertial Sensor*/
};

/*Lateral (Forwards/Backwards) PID Initilization*/
	lemlib::ControllerSettings lateralController
	{
		22, //16, // kP
		0, //1, //kI
		60, //72, // kD
	    0, //1, windupRange
		1, // smallErrorRange
		100, // smallErrorTimeout
		3, // largeErrorRange
		500, // largeErrorTimeout
		30 // Slew Rate
	};
	/*End of Lateral (Forwards/Backwards) PID Initilization*/


	/*Angular (Turning) PID Initilization*/
	lemlib::ControllerSettings angularController
	{
		1.9, // kP
		0, //kI
		20, // kD
		0, //windupRange
		1, // smallErrorRange
		100, // smallErrorTimeout
		3, // largeErrorRange
		500, // largeErrorTimeout
		15 // Slew Rate
	};
	/*End of Angular (Turning) PID Initilization*/

//chassis auton constructor 
lemlib::Chassis chassis( drivetrain , lateralController, angularController, odomsensors );

//pistons
pros::ADIDigitalOut wings(WingPort);
pros::ADIDigitalOut liftup(LiftUpPort);
pros::ADIDigitalOut liftdown(LiftDownPort);
pros::ADIDigitalOut hang(HangPort);
pros::Motor Intake(IntakePort,false);
pros::Motor Kicker(KickerPort,false);
pros::Motor Flywheel(fwport, blueCart, true);
static bool wingtoggle = true;
static bool lifttoggle = true; 
static bool hangtoggle = true; 
static bool intaketoggle = true;
static bool fwtoggle = true;