#include "robotSetup.h"
#include "autoSelect/selection.h"

/**
 * A callback function for LLEMU's center button.
 *
 * When this callback is fired, it will toggle line 2 of the LCD text between
 * "I was pressed!" and nothing.
 */
ASSET(6ball1_txt);
void on_center_button()
{
	static bool pressed = false;
	pressed = !pressed;
	if (pressed)
	{
		pros::lcd::set_text(2, "I was pressed!");
	}
	else
	{
		pros::lcd::clear_line(2);
	}
}

void screen()
{
	// loop forever
	while (true)
	{
		lemlib::Pose pose = chassis.getPose();			// get the current position of the robot
		pros::lcd::print(0, "x: %f", pose.x);			// print the x position
		pros::lcd::print(1, "y: %f", pose.y);			// print the y position
		pros::lcd::print(2, "heading: %f", pose.theta); // print the heading
		pros::delay(10);
	}
}
void initialize()
{
	pros::lcd::initialize();	   // initialize brain screen
	chassis.calibrate();		   // calibrate the chassis
	pros::Task screenTask(screen); // create a task to print the position to the screen
								   // selector::init(); USE FOR AFTER TUNING IS DONE
}
void disabled() {}
void competition_initialize() {}
void autonomous()
{
//chassis.moveToPose(0,30,0,10000);
chassis.turnTo(10,0,10000);
}

void opcontrol()
{
	pros::Controller master(pros::E_CONTROLLER_MASTER);

	while (true)
	{

		chassis.tank(master.get_analog(ANALOG_LEFT_Y), master.get_analog(ANALOG_RIGHT_Y), 7);
		// wings
		if (master.get_digital_new_press(R1))
		{
			if (wingtoggle)
			{
				wings.set_value(1);
			}
			else
			{
				wings.set_value(0);
			}
			wingtoggle = !wingtoggle;
		}

		// lift
		if (master.get_digital_new_press(Up))
		{
			if (lifttoggle)
			{
				liftup.set_value(1);
			}
			else
			{
				liftup.set_value(0);
			}
			lifttoggle = !lifttoggle;
		}

		//fw
		if (master.get_digital_new_press(R2))
		{
			if (fwtoggle)
			{
		Flywheel.move_voltage(12000);
			}
			else
			{
				Flywheel.move_voltage(0);
			}
			fwtoggle = !fwtoggle;
		}
		// intake
		if (master.get_digital(L1))
		{
			Intake.move_voltage(-12000);
		}
		else if (master.get_digital(L2))
		{
			Intake.move_voltage(12000);
		}
		else
		{
			Intake.move_voltage(0);
		}

		// hang
		if (master.get_digital_new_press(Down))
		{
			if (hangtoggle)
			{
				hang.set_value(1);
			}
			else
			{
				hang.set_value(0);
			}
			hangtoggle = !hangtoggle;
		}
		pros::delay(20);
	}
}
